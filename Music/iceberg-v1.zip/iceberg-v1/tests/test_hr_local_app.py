#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path


SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import hr_local_app  # noqa: E402


def fake_evaluate(resume, interview, benchmark, config):
    del resume, interview, config
    dimensions = {}
    for key in ("motivation", "trait", "self_concept", "values"):
        dimensions[key] = {
            "score": 50,
            "signals": [],
            "evidence": [],
            "counter_evidence": [],
            "evidence_coverage": 0,
            "confidence": "low",
            "benchmark_gap": "当前证据不足，暂不判断是否达到画像基准。",
            "validation_questions": [],
        }
    return {
        "above_water_summary": [
            {
                "indicator": item["indicator"],
                "priority": item["priority"],
                "status": "not_evidenced",
                "evidence": [],
                "caveat": "样例未提供可验证证据。",
            }
            for item in benchmark["above_water_indicators"]
        ],
        "iceberg_scores": dimensions,
        "key_strengths": [],
        "risk_flags": ["当前材料不足，需结构化补证。"],
        "llm_report": "当前材料仅支持形成待验证假设，请结合完整追问进行人工复核。",
        "analysis_limitations": ["这是本地体验页离线测试结果。"],
    }


class TestHrLocalApp(unittest.TestCase):
    def setUp(self):
        self.app = hr_local_app.create_app(evaluate_fn=fake_evaluate)
        self.app.testing = True
        self.client = self.app.test_client()

    def test_home_page(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        page = response.get_data(as_text=True)
        self.assertIn("HR 本地体验", page)
        self.assertIn("[hidden]{display:none!important}", page)
        self.assertIn('id="previewStage"', page)
        self.assertIn("reportCanvasWidth=1180", page)
        self.assertIn("适应宽度", page)

    def test_sample_validation_preview_and_download(self):
        response = self.client.post("/api/process", data={"action": "validate", "use_sample": "true"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertTrue(payload["ok"])
        preview = self.client.get(payload["preview_url"])
        self.assertIn("输入校验通过", preview.get_data(as_text=True))
        download = self.client.get(payload["download_url"])
        self.assertIn("attachment", download.headers["Content-Disposition"])

    def test_sample_full_report(self):
        response = self.client.post("/api/process", data={"action": "evaluate", "use_sample": "true"})
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        preview = self.client.get(payload["preview_url"])
        report = preview.get_data(as_text=True)
        self.assertIn("冰山模型软性素质评估报告", report)
        self.assertIn("探索性支持度", report)
        self.assertNotIn("等级：较差", report)


if __name__ == "__main__":
    unittest.main(verbosity=2)
