param(
    [switch]$DryRun,
    [switch]$Web
)

$skillRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Push-Location $skillRoot
try {
    if ($Web) {
        python scripts\hr_local_app.py
        exit $LASTEXITCODE
    }

    $arguments = @(
        "scripts\iceberg_evaluator.py",
        "--resume", "test_candidate_resume.txt",
        "--interview", "test_candidate_interview.json",
        "--benchmark", "test_benchmark.json",
        "--html", "output\test_p02_evaluation.html"
    )
    if ($DryRun) {
        $arguments += "--dry-run"
    }
    python @arguments
    exit $LASTEXITCODE
}
finally {
    Pop-Location
}
